package Dados;

public class exer {

	private double notaA, notaB, notaC;
	
	public void Nota (double d, double e, double f) {
		notaA = d;
		notaB = e;
		notaC = f;
	}
	
	public double obterMedia() {
		
		return (notaA + notaB + notaC)/3;
		
	}

}


