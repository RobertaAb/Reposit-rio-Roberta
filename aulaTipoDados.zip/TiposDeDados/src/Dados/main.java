package Dados;


public class main {
	public static void main (String args[]) {
		
		Nota aluno1 = new Nota(6.5, 7.25, 9.0);
		
	}

}
