package teste;

public class Main {
	
	public static void main(String[] args) {
		
		tempo t1 = new tempo(10);
		
		int a = t1.obterHoras();
		
		System.out.print(t1.obterHoras());
		
	}

}
