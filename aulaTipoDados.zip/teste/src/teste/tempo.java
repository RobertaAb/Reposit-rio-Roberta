package teste;

public class tempo {
	
	public int segundos, minutos, horas, entrada;
	
	public tempo(int s) {
		entrada = s;
	}
	
	public int obterMinutos() {
		
		//..
		return 0;
	}
	
	public int obterHoras() {
		
		//..
		return 0;
	}

}
