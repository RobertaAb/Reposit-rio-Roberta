package conversaodetempo;

public class tempo {
	public int hora;
	public int minuto;
	public int segundo;
	
	public tempo()

	public int obterMinutos()
	{
		
		
	}
}
