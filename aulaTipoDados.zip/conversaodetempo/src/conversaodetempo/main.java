package conversaodetempo;

public class main {
	public static void main(string) []args)

}
